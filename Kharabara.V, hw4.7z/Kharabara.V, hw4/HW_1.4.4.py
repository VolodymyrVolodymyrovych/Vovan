a = []
n = 1
while n != 0:
    n = int(input("0 for exit another count for continue: "))
    b = input("Write some words:")
    a.append(b)
    print(a)
print(a)